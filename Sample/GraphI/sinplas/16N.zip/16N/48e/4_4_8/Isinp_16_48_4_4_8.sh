#!/bin/bash

#PBS -l walltime=648:00:00
#PBS -l nice=19
#PBS -l nodes=1:ppn=1
#PBS -q batch

cd $PBS_O_WORKDIR
../../../rwsinp ${PBS_ARRAYID} 100 16 48 20 2 20 4 4 8
