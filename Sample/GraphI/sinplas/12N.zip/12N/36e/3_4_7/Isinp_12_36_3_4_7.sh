#!/bin/bash

#PBS -l walltime=248:00:00
#PBS -l nice=19
#PBS -l nodes=1:ppn=1
#PBS -q batch

cd $PBS_O_WORKDIR
../../../rwsinp ${PBS_ARRAYID} 500 12 36 20 2 20 3 4 7
