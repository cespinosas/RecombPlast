#!/bin/bash
#PBS -l walltime=750:00:00
#PBS -l nice=19
#PBS -l nodes=1:ppn=1
#PBS -q batch
cd $PBS_O_WORKDIR
../../../../pagor ${PBS_ARRAYID} 16 48 4 4 8 20
