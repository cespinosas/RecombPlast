#!/bin/bash
#PBS -l walltime=98:00:00
#PBS -l nice=19
#PBS -l nodes=1:ppn=1
#PBS -q batch
cd $PBS_O_WORKDIR
../../../../fam_apiv ${PBS_ARRAYID} 12 36 3 3 6 20
